import 'package:dio/dio.dart';
import 'package:lung_diagnosis_app/core/failures/failure.dart';

class NetworkExceptions {
  static AppFailure mapDioError(Object error) {
    if (error is DioException) {
      final status = error.response?.statusCode;
      final serverMessage = _extractServerMessage(error.response?.data);

      if (error.type == DioExceptionType.connectionTimeout ||
          error.type == DioExceptionType.sendTimeout ||
          error.type == DioExceptionType.receiveTimeout) {
        return AppFailure(
          type: FailureType.timeout,
          message: 'Request timed out',
          statusCode: status,
          details: error,
        );
      }

      if (error.type == DioExceptionType.cancel) {
        return AppFailure(
          type: FailureType.network,
          message: 'Request cancelled',
          statusCode: status,
          details: error,
        );
      }

      if (error.type == DioExceptionType.connectionError) {
        return AppFailure(
          type: FailureType.network,
          message: 'No internet connection',
          statusCode: status,
          details: error,
        );
      }

      if (error.type == DioExceptionType.badResponse) {
        final code = status ?? -1;

        if (code == 401) {
          return AppFailure(
            type: FailureType.unauthorized,
            message: serverMessage ?? 'Unauthorized',
            statusCode: code,
            details: error.response?.data,
          );
        }

        if (code == 403) {
          return AppFailure(
            type: FailureType.forbidden,
            message: serverMessage ?? 'Forbidden',
            statusCode: code,
            details: error.response?.data,
          );
        }

        if (code == 404) {
          return AppFailure(
            type: FailureType.notFound,
            message: serverMessage ?? 'Not found',
            statusCode: code,
            details: error.response?.data,
          );
        }

        if (code >= 500) {
          return AppFailure(
            type: FailureType.server,
            message: serverMessage ?? 'Server error',
            statusCode: code,
            details: error.response?.data,
          );
        }

        return AppFailure(
          type: FailureType.server,
          message: serverMessage ?? 'Request failed',
          statusCode: code,
          details: error.response?.data,
        );
      }

      return AppFailure(
        type: FailureType.unknown,
        message: serverMessage ?? 'Network error',
        statusCode: status,
        details: error,
      );
    }

    return AppFailure(
      type: FailureType.unknown,
      message: 'Unknown error',
      details: error,
    );
  }

  static String? _extractServerMessage(dynamic data) {
    if (data == null) return null;
    if (data is String) {
      final value = data.trim();
      return value.isEmpty ? null : value;
    }
    if (data is Map) {
      final map = Map<String, dynamic>.from(data);
      final candidates = [
        map['message'],
        map['title'],
        map['detail'],
        map['error'],
      ];
      for (final candidate in candidates) {
        final value = candidate?.toString().trim();
        if (value != null && value.isNotEmpty) return value;
      }
    }
    return null;
  }
}
