import 'package:lung_diagnosis_app/features/auth/data/dtos/auth_user_dto.dart';

class LoginResponseDto {
  final String accessToken;
  final String refreshToken;
  final AuthUserDto user;

  const LoginResponseDto({
    required this.accessToken,
    required this.refreshToken,
    required this.user,
  });

  factory LoginResponseDto.fromJson(Map<String, dynamic> json) {
    final role = (json['role'] ?? 'Patient').toString();
    return LoginResponseDto(
      accessToken: (json['token'] ?? json['accessToken'] ?? '').toString(),
      refreshToken: (json['refreshToken'] ?? '').toString(),
      user: AuthUserDto(
        id: (json['id'] ?? '').toString(),
        email: (json['email'] ?? '').toString(),
        displayName: (json['userName'] ?? json['name'] ?? json['displayName'] ?? '').toString(),
        role: role,
        status: (json['status'] ?? 'Active').toString(),
      ),
    );
  }
}
