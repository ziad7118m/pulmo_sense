import 'package:lung_diagnosis_app/features/medical_data/data/datasources/medical_profile_remote_data_source.dart';
import 'package:lung_diagnosis_app/features/medical_data/data/mappers/medical_profile_mapper.dart';
import 'package:lung_diagnosis_app/features/medical_data/domain/entities/medical_profile_record.dart';
import 'package:lung_diagnosis_app/features/medical_data/domain/repositories/medical_profile_repository.dart';

class MedicalProfileRepositoryImpl implements MedicalProfileRepository {
  final MedicalProfileRemoteDataSource _remote;

  const MedicalProfileRepositoryImpl({
    required MedicalProfileRemoteDataSource remote,
  }) : _remote = remote;

  @override
  Future<MedicalProfileRecord?> getProfile(String ownerId) async {
    final normalized = ownerId.trim();
    if (normalized.isEmpty) return null;

    final remoteProfile = await _remote.getProfile(normalized);
    return remoteProfile == null ? null : MedicalProfileMapper.fromDto(remoteProfile);
  }

  @override
  Future<void> saveProfile(MedicalProfileRecord profile) async {
    await _remote.saveProfile(MedicalProfileMapper.toDto(profile));
  }

  @override
  Future<void> deleteProfile(String ownerId) async {
    final normalized = ownerId.trim();
    if (normalized.isEmpty) return;
    await _remote.deleteProfile(normalized);
  }
}
