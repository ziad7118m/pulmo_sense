class Endpoints {
  // Diagnosis
  static const String analyzeRecord = '/api/diagnosis/record';
  static const String analyzeAudio = '/api/diagnosis/audio';
  static const String analyzeXray = '/api/diagnosis/xray';
  static const String diagnoses = '/api/diagnoses';
  static const String diagnosesLatest = '/api/diagnoses/latest';

  // Auth
  static const String login = '/api/Authenticationes/Login';
  static const String patientRegister = '/api/Authenticationes/PatientRegister';
  static const String doctorRegister = '/api/Authenticationes/DoctorRegister';
  static const String sendOtp = '/api/Authenticationes/send-otp';
  static const String verifyOtp = '/api/Authenticationes/verify-otp';
  static const String refresh = '/api/Authenticationes/refresh-token';
  static const String logout = '/api/Authenticationes/logout';
  static const String me = '/api/Authenticationes/me';
  static const String forgotPassword = '/api/Authenticationes/ForgetPassword';
  static const String resetPassword = '/api/Authenticationes/ResetPassword';

  // Password reset flow in Flutter still refers to a separate verification step,
  // but the backend validates the OTP again inside ResetPassword.
  static const String verifyResetCode = verifyOtp;

  // Admin users
  static const String pendingUsers = '/api/Admin/pending-users';
  static String approveUser(String id) => '/api/Admin/approve/$id';
  static String rejectUser(String id) => '/api/Admin/reject/$id';

  // Profiles
  static const String myProfile = '/api/users/me/profile';
  static const String userProfile = '/api/users';
  static const String medicalProfiles = '/api/medical-profiles';

  // Articles
  static const String articles = '/api/articles';
  static const String articleMine = '/api/articles/mine';
  static const String articleFavourites = '/api/articles/favourites';
  static const String articleSaved = '/api/articles/saved';

  // Doctor access / QR
  static const String doctorPatientResolve = '/api/doctors/patient-access/resolve';
  static const String qrResolve = '/api/qr/resolve';
}
