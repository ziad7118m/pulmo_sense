import 'package:lung_diagnosis_app/shared/domain/enums/user_role.dart';

class MedicalProfileDto {
  final String ownerId;
  final UserRole ownerRole;
  final Map<String, double> factors;
  final List<String> diseases;
  final String createdByDoctorId;
  final String createdByDoctorName;
  final DateTime updatedAt;

  const MedicalProfileDto({
    required this.ownerId,
    required this.ownerRole,
    required this.factors,
    required this.diseases,
    required this.createdByDoctorId,
    required this.createdByDoctorName,
    required this.updatedAt,
  });

  static const Map<String, List<String>> _factorAliases = {
    'Obesity': ['obesity', 'Obesity'],
    'Coughing of blood': ['coughingOfBlood', 'coughing_of_blood', 'CoughingOfBlood'],
    'Alcohol use': ['alcoholUse', 'alcohol_use', 'AlcoholUse'],
    'Dust allergy': ['dustAllergy', 'dust_allergy', 'DustAllergy'],
    'Balanced diet': ['balancedDiet', 'balanced_diet', 'BalancedDiet'],
    'Passive smoker': ['passiveSmoker', 'passive_smoker', 'PassiveSmoker'],
    'Genetic risk': ['geneticRisk', 'genetic_risk', 'GeneticRisk'],
    'Occupational hazards': [
      'occupationalHazards',
      'occupational_hazards',
      'OccupationalHazards',
    ],
    'Chest pain': ['chestPain', 'chest_pain', 'ChestPain'],
    'Air pollution': ['airPollution', 'air_pollution', 'AirPollution'],
  };

  factory MedicalProfileDto.fromJson(Map<String, dynamic> json) {
    final rawFactors = _extractFactors(json);
    return MedicalProfileDto(
      ownerId: (json['ownerId'] ?? json['userId'] ?? json['patientId'] ?? json['id'] ?? '')
          .toString(),
      ownerRole: UserRoleX.fromValue(
        (json['ownerRole'] ?? json['role'] ?? 'patient').toString(),
      ),
      factors: rawFactors,
      diseases: _extractDiseases(json),
      createdByDoctorId:
          (json['createdByDoctorId'] ?? json['doctorId'] ?? json['createdBy'] ?? '')
              .toString(),
      createdByDoctorName:
          (json['createdByDoctorName'] ?? json['doctorName'] ?? json['createdByName'] ?? '')
              .toString(),
      updatedAt: DateTime.tryParse(
            (json['updatedAt'] ?? json['lastUpdatedAt'] ?? json['createdAt'] ?? '')
                .toString(),
          ) ??
          DateTime.now(),
    );
  }

  MedicalProfileDto copyWith({
    String? ownerId,
    UserRole? ownerRole,
    Map<String, double>? factors,
    List<String>? diseases,
    String? createdByDoctorId,
    String? createdByDoctorName,
    DateTime? updatedAt,
  }) {
    return MedicalProfileDto(
      ownerId: ownerId ?? this.ownerId,
      ownerRole: ownerRole ?? this.ownerRole,
      factors: factors ?? this.factors,
      diseases: diseases ?? this.diseases,
      createdByDoctorId: createdByDoctorId ?? this.createdByDoctorId,
      createdByDoctorName: createdByDoctorName ?? this.createdByDoctorName,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  Map<String, dynamic> toJson() {
    final payload = <String, dynamic>{
      'ownerId': ownerId,
      'userId': ownerId,
      'patientId': ownerId,
      'ownerRole': ownerRole.name,
      'role': ownerRole.name,
      'factors': factors,
      'diseases': diseases,
      'createdByDoctorId': createdByDoctorId,
      'doctorId': createdByDoctorId,
      'createdByDoctorName': createdByDoctorName,
      'doctorName': createdByDoctorName,
      'updatedAt': updatedAt.toIso8601String(),
    };

    for (final entry in _factorAliases.entries) {
      final value = factors[entry.key] ?? 0;
      for (final alias in entry.value) {
        payload[alias] = value;
      }
    }

    return payload;
  }

  static Map<String, double> _extractFactors(Map<String, dynamic> json) {
    final nestedFactors = json['factors'];
    if (nestedFactors is Map) {
      return Map<String, dynamic>.from(nestedFactors).map(
        (key, value) => MapEntry(key, (value as num?)?.toDouble() ?? 0),
      );
    }

    final resolved = <String, double>{};
    for (final entry in _factorAliases.entries) {
      resolved[entry.key] = _extractDouble(json, entry.value) ?? 0;
    }
    return resolved;
  }

  static List<String> _extractDiseases(Map<String, dynamic> json) {
    final direct = json['diseases'];
    if (direct is List) {
      return direct.map((e) => e.toString()).toList(growable: false);
    }

    final medicalHistory = json['medicalHistory'];
    if (medicalHistory is List) {
      return medicalHistory.map((e) => e.toString()).toList(growable: false);
    }

    return const <String>[];
  }

  static double? _extractDouble(Map<String, dynamic> json, List<String> keys) {
    for (final key in keys) {
      final value = json[key];
      if (value is num) return value.toDouble();
      if (value is String) {
        final parsed = double.tryParse(value);
        if (parsed != null) return parsed;
      }
    }
    return null;
  }
}
