import 'package:lung_diagnosis_app/core/failures/failure.dart';
import 'package:lung_diagnosis_app/core/network/api_client.dart';
import 'package:lung_diagnosis_app/core/network/endpoints.dart';
import 'package:lung_diagnosis_app/core/result/result.dart';
import 'package:lung_diagnosis_app/core/session/session_context.dart';
import 'package:lung_diagnosis_app/features/medical_data/data/dtos/medical_profile_dto.dart';

class MedicalProfileRemoteDataSource {
  final ApiClient _client;
  bool _backendUnsupported = false;

  MedicalProfileRemoteDataSource(this._client);

  static const AppFailure _unsupportedFailure = AppFailure(
    type: FailureType.notFound,
    statusCode: 404,
    message: 'Medical profile API is not available on the current backend.',
  );

  String _ownerPath(String ownerId) => '${Endpoints.medicalProfiles}/${ownerId.trim()}';

  bool _isCurrentUser(String ownerId) {
    final requested = ownerId.trim();
    final current = (SessionContext.userId ?? '').trim();
    return requested.isNotEmpty && current.isNotEmpty && requested == current;
  }

  Map<String, dynamic> _extractMap(dynamic data) {
    if (data is Map<String, dynamic>) {
      final nested = data['data'] ?? data['item'] ?? data['result'] ?? data['profile'];
      if (nested is Map) {
        return Map<String, dynamic>.from(nested);
      }
      return data;
    }
    if (data is Map) {
      return Map<String, dynamic>.from(data);
    }
    return <String, dynamic>{};
  }

  List<Map<String, dynamic>> _extractList(dynamic data) {
    dynamic candidate = data;
    if (data is Map<String, dynamic>) {
      candidate = data['data'] ?? data['items'] ?? data['results'] ?? data['profiles'] ?? data;
    } else if (data is Map) {
      final map = Map<String, dynamic>.from(data);
      candidate = map['data'] ?? map['items'] ?? map['results'] ?? map['profiles'] ?? map;
    }

    if (candidate is List) {
      return candidate
          .whereType<Map>()
          .map((item) => Map<String, dynamic>.from(item))
          .toList(growable: false);
    }

    return const <Map<String, dynamic>>[];
  }

  MedicalProfileDto? _decodeProfile(dynamic data, String fallbackOwnerId) {
    final map = _extractMap(data);
    if (map.isNotEmpty) {
      return _normalizeOwnerId(MedicalProfileDto.fromJson(map), fallbackOwnerId);
    }

    final list = _extractList(data);
    if (list.isNotEmpty) {
      return _normalizeOwnerId(MedicalProfileDto.fromJson(list.first), fallbackOwnerId);
    }

    return null;
  }

  MedicalProfileDto _normalizeOwnerId(MedicalProfileDto dto, String ownerId) {
    if (dto.ownerId.trim().isNotEmpty) return dto;
    return dto.copyWith(ownerId: ownerId);
  }

  bool _isNotFoundResult<T>(Result<T> result) {
    if (result is! FailureResult<T>) return false;
    return result.failure.type == FailureType.notFound || result.failure.statusCode == 404;
  }

  bool _isMethodNotAllowedResult<T>(Result<T> result) {
    if (result is! FailureResult<T>) return false;
    return result.failure.statusCode == 405;
  }

  bool _canFallbackToCreate<T>(Result<T> result) {
    if (result is! FailureResult<T>) return false;
    final status = result.failure.statusCode;
    return status == 404 || status == 405;
  }

  void _throwIfFailed<T>(Result<T> result) {
    if (result is FailureResult<T>) {
      throw result.failure;
    }
  }

  Future<_ProfileLookupResult> _tryGetProfile(
    String path,
    String fallbackOwnerId, {
    Map<String, dynamic>? query,
  }) async {
    final result = await _client.get<dynamic>(
      path,
      query: query,
      decode: (data) => data,
    );

    if (result is Success<dynamic>) {
      return _ProfileLookupResult.success(_decodeProfile(result.value, fallbackOwnerId));
    }

    if (_isNotFoundResult(result)) {
      return const _ProfileLookupResult.notFound();
    }

    _throwIfFailed(result);
    return const _ProfileLookupResult.notFound();
  }

  Future<MedicalProfileDto?> getProfile(String ownerId) async {
    if (_backendUnsupported) return null;

    final normalized = ownerId.trim();
    if (normalized.isEmpty) return null;

    _ProfileLookupResult? selfProfile;
    if (_isCurrentUser(normalized)) {
      selfProfile = await _tryGetProfile(
        Endpoints.medicalMyProfile,
        normalized,
      );
      if (selfProfile.profile != null) return selfProfile.profile;
    }

    final byIdProfile = await _tryGetProfile(_ownerPath(normalized), normalized);
    if (byIdProfile.profile != null) return byIdProfile.profile;

    final queryProfile = await _tryGetProfile(
      Endpoints.medicalProfiles,
      normalized,
      query: {'ownerId': normalized},
    );
    if (queryProfile.profile != null) return queryProfile.profile;

    final selfMissing = selfProfile == null || selfProfile.notFound;
    if (byIdProfile.notFound && queryProfile.notFound && selfMissing) {
      _backendUnsupported = true;
    }

    return null;
  }

  Future<void> saveProfile(MedicalProfileDto profile) async {
    if (_backendUnsupported) throw _unsupportedFailure;

    final normalized = profile.ownerId.trim();
    if (normalized.isEmpty) return;

    final normalizedProfile = _normalizeOwnerId(profile, normalized);
    Result<dynamic>? selfPut;
    Result<dynamic>? putById;
    Result<dynamic>? create;
    Result<dynamic>? selfCreate;

    if (_isCurrentUser(normalized)) {
      selfPut = await _client.put<dynamic>(
        Endpoints.medicalMyProfile,
        body: normalizedProfile.toJson(),
      );
      if (selfPut is Success<dynamic>) return;
      if (!_canFallbackToCreate(selfPut)) {
        _throwIfFailed(selfPut);
      }
    }

    putById = await _client.put<dynamic>(
      _ownerPath(normalized),
      body: normalizedProfile.toJson(),
    );
    if (putById is Success<dynamic>) return;
    if (!_canFallbackToCreate(putById)) {
      _throwIfFailed(putById);
    }

    create = await _client.post<dynamic>(
      Endpoints.medicalProfiles,
      body: normalizedProfile.toJson(),
    );
    if (create is Success<dynamic>) return;

    if (_isCurrentUser(normalized)) {
      selfCreate = await _client.post<dynamic>(
        Endpoints.medicalMyProfile,
        body: normalizedProfile.toJson(),
      );
      if (selfCreate is Success<dynamic>) return;
    }

    final baseCreateMissing = create != null && _isNotFoundResult(create);
    final selfWriteMissing = selfPut == null || _isNotFoundResult(selfPut) || _isMethodNotAllowedResult(selfPut);
    final byIdWriteMissing = _isNotFoundResult(putById) || _isMethodNotAllowedResult(putById);
    final selfCreateMissing = selfCreate == null || _isNotFoundResult(selfCreate);

    if (baseCreateMissing && byIdWriteMissing && selfWriteMissing && selfCreateMissing) {
      _backendUnsupported = true;
      throw _unsupportedFailure;
    }

    if (selfCreate != null) {
      _throwIfFailed(selfCreate);
    }
    _throwIfFailed(create);
  }

  Future<void> deleteProfile(String ownerId) async {
    if (_backendUnsupported) return;

    final normalized = ownerId.trim();
    if (normalized.isEmpty) return;

    Result<dynamic>? selfDelete;
    if (_isCurrentUser(normalized)) {
      selfDelete = await _client.delete<dynamic>(Endpoints.medicalMyProfile);
      if (selfDelete is Success<dynamic> || _isNotFoundResult(selfDelete)) {
        return;
      }
      if (!_isMethodNotAllowedResult(selfDelete)) {
        _throwIfFailed(selfDelete);
      }
    }

    final result = await _client.delete<dynamic>(_ownerPath(normalized));
    if (result is Success<dynamic> || _isNotFoundResult(result)) return;

    if (_isMethodNotAllowedResult(result) && selfDelete != null && _isMethodNotAllowedResult(selfDelete)) {
      _backendUnsupported = true;
      return;
    }

    _throwIfFailed(result);
  }
}

class _ProfileLookupResult {
  final MedicalProfileDto? profile;
  final bool notFound;

  const _ProfileLookupResult._({required this.profile, required this.notFound});

  const _ProfileLookupResult.notFound() : this._(profile: null, notFound: true);

  const _ProfileLookupResult.success(MedicalProfileDto? profile)
      : this._(profile: profile, notFound: false);
}
