import 'package:lung_diagnosis_app/core/failures/failure.dart';
import 'package:lung_diagnosis_app/features/medical_data/data/datasources/medical_profile_remote_data_source.dart';
import 'package:lung_diagnosis_app/features/medical_data/data/in_memory_medical_profile_store.dart';
import 'package:lung_diagnosis_app/features/medical_data/data/mappers/medical_profile_mapper.dart';
import 'package:lung_diagnosis_app/features/medical_data/domain/entities/medical_profile_record.dart';
import 'package:lung_diagnosis_app/features/medical_data/domain/repositories/medical_profile_repository.dart';

class MedicalProfileRepositoryImpl implements MedicalProfileRepository {
  final MedicalProfileRemoteDataSource _remote;
  final InMemoryMedicalProfileStore _local;

  MedicalProfileRepositoryImpl({
    required MedicalProfileRemoteDataSource remote,
    required InMemoryMedicalProfileStore local,
  })  : _remote = remote,
        _local = local;

  bool _shouldUseLocalFallback(Object error) {
    if (error is! AppFailure) return false;
    return error.type == FailureType.notFound || error.statusCode == 404 || error.statusCode == 405;
  }

  @override
  Future<MedicalProfileRecord?> getProfile(String ownerId) async {
    final normalized = ownerId.trim();
    if (normalized.isEmpty) return null;

    final remoteProfile = await _remote.getProfile(normalized);
    if (remoteProfile != null) {
      final mapped = MedicalProfileMapper.fromDto(remoteProfile);
      await _local.upsert(mapped);
      return mapped;
    }

    return _local.getProfile(normalized);
  }

  @override
  Future<void> saveProfile(MedicalProfileRecord profile) async {
    try {
      await _remote.saveProfile(MedicalProfileMapper.toDto(profile));
    } catch (error) {
      if (!_shouldUseLocalFallback(error)) rethrow;
    }

    await _local.upsert(profile);
  }

  @override
  Future<void> deleteProfile(String ownerId) async {
    final normalized = ownerId.trim();
    if (normalized.isEmpty) return;

    try {
      await _remote.deleteProfile(normalized);
    } catch (error) {
      if (!_shouldUseLocalFallback(error)) rethrow;
    }

    await _local.delete(normalized);
  }
}
