import 'package:lung_diagnosis_app/core/di/app_di.dart';
import 'package:lung_diagnosis_app/core/network/endpoints.dart';
import 'package:lung_diagnosis_app/core/result/result.dart';
import 'package:lung_diagnosis_app/features/medical_data/domain/entities/medical_profile_record.dart';

class LungRiskAnalyzer {
  const LungRiskAnalyzer._();

  static Future<double> analyzeOverallRisk(MedicalProfileRecord? medical) async {
    if (medical == null || medical.factors.isEmpty) {
      return 0.0;
    }

    final payload = <String, dynamic>{
      'obesity': _factor(medical, 'Obesity'),
      'coughingOfBlood': _factor(medical, 'Coughing of blood'),
      'alcoholUse': _factor(medical, 'Alcohol use'),
      'dustAllergy': _factor(medical, 'Dust allergy'),
      'passiveSmoker': _factor(medical, 'Passive smoker'),
      'balancedDiet': _factor(medical, 'Balanced diet'),
      'geneticRisk': _factor(medical, 'Genetic risk'),
      'occupationalHazards': _factor(medical, 'Occupational hazards'),
      'chestPain': _factor(medical, 'Chest pain'),
      'airPollution': _factor(medical, 'Air pollution'),
    };

    final result = await AppDI.apiClient.post<Map<String, dynamic>>(
      Endpoints.lungRiskAnalyze,
      body: payload,
      decode: (dynamic data) => _extractMap(data),
    );

    if (result is Success<Map<String, dynamic>>) {
      final high = _extractHighRisk(result.value);
      if (high != null) {
        return _normalizePercent(high);
      }
    }

    return localFallback(medical);
  }

  static double localFallback(MedicalProfileRecord? medical) {
    final factors = medical?.factors.values.toList() ?? const <double>[];
    if (factors.isEmpty) return 0.0;
    return factors.reduce((a, b) => a + b) / factors.length;
  }

  static int _factor(MedicalProfileRecord medical, String key) {
    final raw = medical.factors[key] ?? 0;
    return (raw / 10).round().clamp(0, 10);
  }

  static Map<String, dynamic> _extractMap(dynamic data) {
    if (data is Map<String, dynamic>) {
      final nested = data['data'];
      if (nested is Map<String, dynamic>) {
        return nested;
      }
      if (nested is Map) {
        return Map<String, dynamic>.from(nested);
      }
      return data;
    }
    if (data is Map) {
      return Map<String, dynamic>.from(data);
    }
    return <String, dynamic>{};
  }

  static double? _extractHighRisk(Map<String, dynamic> map) {
    const directKeys = [
      'high',
      'High',
      'highRisk',
      'HighRisk',
      'risk',
      'Risk',
      'high_percentage',
      'highPercentage',
    ];

    for (final key in directKeys) {
      final value = _asDouble(map[key]);
      if (value != null) {
        return value;
      }
    }

    for (final entry in map.entries) {
      final normalizedKey = entry.key.toLowerCase().replaceAll('_', '');
      if (normalizedKey == 'high' ||
          normalizedKey == 'highrisk' ||
          normalizedKey == 'highpercentage') {
        final value = _asDouble(entry.value);
        if (value != null) {
          return value;
        }
      }
    }

    return null;
  }

  static double _normalizePercent(double value) {
    if (value <= 1) {
      return (value * 100).clamp(0, 100).toDouble();
    }
    return value.clamp(0, 100).toDouble();
  }

  static double? _asDouble(dynamic value) {
    if (value is num) return value.toDouble();
    if (value is String) return double.tryParse(value);
    return null;
  }
}
