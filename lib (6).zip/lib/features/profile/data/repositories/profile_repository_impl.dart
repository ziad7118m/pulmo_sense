import 'package:lung_diagnosis_app/features/profile/data/datasources/profile_remote_data_source.dart';
import 'package:lung_diagnosis_app/features/profile/data/mappers/profile_mapper.dart';
import 'package:lung_diagnosis_app/features/profile/domain/entities/user_profile.dart';
import 'package:lung_diagnosis_app/features/profile/domain/repositories/profile_repository.dart';

class ProfileRepositoryImpl implements ProfileRepository {
  final ProfileRemoteDataSource _remote;

  const ProfileRepositoryImpl({
    required ProfileRemoteDataSource remote,
  }) : _remote = remote;

  @override
  Future<UserProfile?> getProfile(String userId) async {
    final normalized = userId.trim();
    if (normalized.isEmpty) return null;

    final remoteProfile = await _remote.getProfile(normalized);
    return remoteProfile == null ? null : ProfileMapper.toDomain(remoteProfile);
  }

  @override
  Future<UserProfile> getOrCreate(String userId) async {
    final normalized = userId.trim();
    final resolved = await getProfile(normalized);
    return resolved ?? UserProfile.empty(normalized);
  }

  @override
  Future<void> upsert(UserProfile profile) async {
    await _remote.upsert(ProfileMapper.toDto(profile));
  }

  @override
  Future<void> deleteProfile(String userId) async {
    final normalized = userId.trim();
    if (normalized.isEmpty) return;
    await _remote.deleteProfile(normalized);
  }

  @override
  Future<String?> findUserIdByNationalId(String nationalId) async {
    final normalized = nationalId.trim();
    if (normalized.isEmpty) return null;
    return _remote.findUserIdByNationalId(normalized);
  }
}
