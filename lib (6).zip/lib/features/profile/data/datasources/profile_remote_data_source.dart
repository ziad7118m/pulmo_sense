import 'package:lung_diagnosis_app/core/network/api_client.dart';
import 'package:lung_diagnosis_app/core/network/endpoints.dart';
import 'package:lung_diagnosis_app/core/session/session_context.dart';
import 'package:lung_diagnosis_app/features/profile/data/dtos/profile_dto.dart';

class ProfileRemoteDataSource {
  final ApiClient _client;

  const ProfileRemoteDataSource(this._client);

  String _userProfilePath(String userId) =>
      '${Endpoints.userProfile}/${userId.trim()}/profile';

  bool _isCurrentUser(String userId) {
    final requested = userId.trim();
    final current = (SessionContext.userId ?? '').trim();
    return requested.isNotEmpty && current.isNotEmpty && requested == current;
  }

  String _profilePath(String userId) {
    return _isCurrentUser(userId) ? Endpoints.myProfile : _userProfilePath(userId);
  }

  Map<String, dynamic> _extractMap(dynamic data) {
    if (data is Map<String, dynamic>) {
      final nested = data['data'];
      if (nested is Map) {
        return Map<String, dynamic>.from(nested);
      }
      return data;
    }
    if (data is Map) {
      return Map<String, dynamic>.from(data);
    }
    return <String, dynamic>{};
  }

  Future<ProfileDto?> getProfile(String userId) async {
    final normalized = userId.trim();
    if (normalized.isEmpty) return null;

    final result = await _client.get<Map<String, dynamic>>(
      _profilePath(normalized),
      decode: (data) => _extractMap(data),
    );

    return result.when(
      success: (payload) {
        if (payload.isEmpty) return null;

        final dto = ProfileDto.fromJson(payload);
        if (dto.userId.trim().isNotEmpty) {
          return dto;
        }

        return ProfileDto(
          userId: normalized,
          nationalId: dto.nationalId,
          address: dto.address,
          phone: dto.phone,
          birthDate: dto.birthDate,
          gender: dto.gender,
          maritalStatus: dto.maritalStatus,
          doctorLicense: dto.doctorLicense,
          avatarPath: dto.avatarPath,
          updatedAt: dto.updatedAt,
        );
      },
      failure: (_) => null,
    );
  }

  Future<void> upsert(ProfileDto dto) async {
    final normalized = dto.userId.trim();
    if (normalized.isEmpty) return;
    await _client.put<dynamic>(
      _profilePath(normalized),
      body: dto.toJson(),
    );
  }

  Future<void> deleteProfile(String userId) async {
    final normalized = userId.trim();
    if (normalized.isEmpty) return;
    await _client.delete<dynamic>(_profilePath(normalized));
  }

  Future<String?> findUserIdByNationalId(String nationalId) async {
    final normalized = nationalId.trim();
    if (normalized.isEmpty) return null;

    final result = await _client.get<Map<String, dynamic>>(
      Endpoints.doctorPatientResolve,
      query: {'nationalId': normalized},
      decode: (data) => _extractMap(data),
    );

    return result.when(
      success: (payload) {
        final nestedPatient = payload['patient'];
        if (nestedPatient is Map) {
          final patientMap = Map<String, dynamic>.from(nestedPatient);
          final nestedId =
              (patientMap['userId'] ?? patientMap['patientId'] ?? patientMap['id'] ?? '')
                  .toString()
                  .trim();
          if (nestedId.isNotEmpty) return nestedId;
        }

        final directId = (payload['userId'] ?? payload['patientId'] ?? payload['id'] ?? '')
            .toString()
            .trim();
        return directId.isEmpty ? null : directId;
      },
      failure: (_) => null,
    );
  }
}
